Base from the Nexus.  Rewards system for the Resurgent Network Valheim Server **only**  
Assets used for the server
